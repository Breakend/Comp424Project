package sXXXXXXXXX.mytools;

public class MyTools {

	public static double getSomething(){
		return Math.random();
	}
}
